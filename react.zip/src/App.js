import React, { useState, useEffect } from "react";
import './App.css';
import money from './media/money@2x.svg'
import energy from'./media/energy.svg'
import people from './media/Group 1.svg'
import symbol from './media/image 1.svg' 
import credit from './media/credit.svg'


const App = () => {
  const [regions, setRegions] = useState([]);
  const [balance, setBalance] = useState([]);

      useEffect(() => {
        fetch("/data.json")
      .then((response) => response.json())
      .then((data) => {
        setRegions(data.Regions);
        setBalance(data.Balance); 
      })
      .catch((error) => console.error("Error fetching data:", error));

  }, []);

  return (
    <div className="container">
      <header className="header">
        <div id="consumables">
          <div className="icons1" id="money">
            <img className="icons" src={money} alt="Money"/>
            <p className="text1">{balance.kazna}</p>
          </div>
          <div className="icons1" id="energy">
            <img className="icons" src={energy} alt="Energy" />
            <p className="text1">{balance.energy}</p>
          </div>
        </div>

        <img id="symbol" src={symbol} alt="Symbol" />

        <div id="world">
          <div className="icons2" id="people">
            <p className="text1">{balance.population}</p>
            <img className="icons" src={people} alt="People" />
          </div>
          <div className="icons2" id="credit">
            <p className="text1">{balance.credit}</p>
            <img className="icons" src={credit} alt="Credit" />
          </div>
        </div>
      </header>

      <main className="content">
        {regions.map((region, index) => (
          <a
            href={`./${region.name}.html`}
            className="regions"
            id={`region${index + 1}`}
            key={index}
          >
            <div className="text-r">{region.name} область</div>
          </a>
        ))}
      </main>

      <footer className="footer">
        <div className="navbar">
          <div className="export">
            <a href="./Експорт.html" className="link-nav">
              <img src="./media/export.svg" alt="Export" id="export" />
            </a>
          </div>
          <div className="home">
            <a href="./index.html" className="link-nav">
              <img src="./media/home.svg" alt="Home" id="home" />
            </a>
          </div>
          <div className="import">
            <a href="./Імпорт.html" className="link-nav">
              <img src="./media/import.svg" alt="Import" id="import" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
